#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{
      nn tt;
      set<nn>s;
      cin>>tt;
      while(tt--)
      {
          nn x;
          cin>>x;
          if(x>0) s.insert(x);
      }
      cout<<s.size()<<endl;



}