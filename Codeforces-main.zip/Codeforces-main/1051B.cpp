#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{
    ll l,r;
    cin>>l>>r;
    cout<<"YES\n";
    for(ll i=l;i<=r;i=i+2) cout<<i<<" "<<i+1<<"\n";

}