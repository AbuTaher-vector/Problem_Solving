#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{
     nn tt;
     cin>>tt;
     if(tt==1) cout<<-1<<endl;
     else cout<<tt<<" "<<tt<<endl;



}