#include<bits/stdc++.h>
using namespace std;
int main()
{
    int tt;
    cin>>tt;
    string s;
    cin>>s;
   cout<<++tt<<endl;

}