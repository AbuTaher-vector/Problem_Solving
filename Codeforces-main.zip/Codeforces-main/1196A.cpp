#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
    ll tt;
    cin>>tt;
    while(tt--)
    {
        ll a,b,c;
        cin>>a>>b>>c;
        cout<<(a+b+c)/2<<endl;
    }
}