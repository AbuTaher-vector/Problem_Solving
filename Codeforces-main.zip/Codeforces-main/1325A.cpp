#include<bits/stdc++.h>
using namespace std;
int main()
{
    int tt;
    cin>>tt;
    while(tt--)
    {
        int x;
        cin>>x;
        cout<<x-1<<" "<<1<<endl;
    }
}