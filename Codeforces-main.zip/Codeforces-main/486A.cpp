#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{
	ll t;
	cin>>t;
	
	if(t%2==0) cout<<t/2<<"\n";
	else cout<<"-"<<t/2+1<<"\n";



}