#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,m,fact;
    cin>>n>>m;
    fact=min(n,m);
    if(fact%2!=0) cout<<"Akshat"<<endl;
    else cout<<"Malvika"<<endl;
}