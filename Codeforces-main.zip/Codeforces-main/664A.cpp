#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{
           ss a,b;
           cin>>a>>b;
           if(a==b) cout<<a<<endl;
           else cout<<1<<endl;
}
