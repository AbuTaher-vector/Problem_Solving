#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{

     nn n,S;
     cin>>n>>S;
     if(S%n==0) cout<<S/n<<endl;
     else cout<<S/n+1<<endl;

}
