#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{

          ss s;
          cin>>s;
          nn k=s.size();
          nn t=k+1;
          cout<<26*t-k<<endl;
}

