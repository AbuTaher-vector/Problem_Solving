#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define string ss
int main()
{
      nn tt;
      cin>>tt;
      while(tt--)
      {
          nn a,b,c,d;
          cin>>a>>b>>c>>d;
          if(a==c) a++;
          cout<<a<<" "<<c<<endl;

      }
}