#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
       ll tt;
       cin>>tt;

       cout<<25<<endl;
}