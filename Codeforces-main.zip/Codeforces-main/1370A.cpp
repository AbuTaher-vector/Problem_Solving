#include<bits/stdc++.h>
using namespace std;
int main()
{
    int x,t;
    cin>>t;
    while(t--)
    {
         cin>>x;
    cout<<x/2<<endl;
    }

}