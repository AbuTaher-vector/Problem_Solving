#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,m,k;
    cin>>n>>m>>k;
    if(n<=m && n<=k) cout<<"YES"<<endl;
    else cout<<"NO"<<endl;
}