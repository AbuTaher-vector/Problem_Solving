#include<bits/stdc++.h>
using namespace std;
int main()
{
    int tt;
    cin>>tt;
    while(tt--)
    {
        int nn;
        cin>>nn;
        string s;
        cin>>s;
        for(int i=0;i<nn;i++)
        {
            cout<<s[nn-1];
        }
        cout<<endl;
    }
}