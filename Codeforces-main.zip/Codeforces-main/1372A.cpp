#include<bits/stdc++.h>
using namespace std;
int main()
{
    int tt;
    cin>>tt;
    while(tt--)
    {
        int ttt;
        cin>>ttt;
        while(ttt--) cout<<1<<" ";
        cout<<endl;

    }
}