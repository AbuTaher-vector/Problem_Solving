#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{
         nn x;
       cin>>x;
       nn t=8;
      if(x%2!=0) t++;
      cout<<t+x<<" "<<t<<endl;

}