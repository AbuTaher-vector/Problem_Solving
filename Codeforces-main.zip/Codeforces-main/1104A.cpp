#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{

        nn x;
        cin>>x;
        cout<<x<<endl;
        for(nn i=1;i<=x;i++) cout<<1<<" ";
        cout<<endl;


}