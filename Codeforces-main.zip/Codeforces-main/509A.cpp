#include<bits/stdc++.h>
using namespace std;
int arr[]={1,2,6,20,70,252,924,3432,12870,48620};
int main()
{
    int t;
    cin>>t;
    cout<<arr[t-1]<<endl;
}