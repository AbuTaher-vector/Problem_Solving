#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{
	ss s;
	cin>>s;
	while(getline(cin,s))
	{
		cout<<"NO\n";
	}
	
}