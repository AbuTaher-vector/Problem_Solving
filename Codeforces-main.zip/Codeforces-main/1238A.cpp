#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{
    nn tt;
    cin>>tt;
    while(tt--)
    {
            ll x,y;
          cin>>x>>y;
         if(x-y>1) cout<<"YES"<<endl;
        else cout<<"NO"<<endl;

    }

}