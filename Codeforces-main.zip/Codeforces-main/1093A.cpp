#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{

   nn tt;
   cin>>tt;
   while(tt--)
   {

    nn x;
    cin>>x;
    if(x%7==0) cout<<x/7<<endl;
    else cout<<(x/7)+1<<endl;

   }

}
