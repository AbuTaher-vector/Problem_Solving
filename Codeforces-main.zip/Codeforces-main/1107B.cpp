#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
#define nl "\n"
void code()
{
      ll k,n;
      cin>>k>>n;
      cout<<(k-1)*9+n<<nl;
} 
int main()
{
     nn tt;
     cin>>tt;
     while(tt--) code();
 
}