#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{
           ll n,k;
           cin>>n>>k;
           if((n/k)%2!=0) cout<<"YES"<<endl;
           else cout<<"NO"<<endl;
}