#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,x;
    cin>>t;
    while(t--)
    {
        cin>>x;
        if(x%4==0) cout<<"YES"<<endl;
        else cout<<"NO"<<endl;

            }
}