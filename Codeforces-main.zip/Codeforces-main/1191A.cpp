#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
int main()
{

       nn tt;
       cin>>tt;
       if(tt%4==1) cout<<0<<" "<<'A'<<endl;
       else if(tt%4==2) cout<<1<<" "<<'B'<<endl;
       else if(tt%4==3) cout<<2<<" "<<'A'<<endl;
       else cout<<1<<" "<<'A'<<endl;

}