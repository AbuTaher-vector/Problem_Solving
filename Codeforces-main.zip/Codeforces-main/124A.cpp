#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
#define nl "\n"
void code()
{
    nn n,a,b;
    cin>>n>>a>>b;
  if(a+b<n) cout<<b+1<<nl;
  else if(a+b==n) cout<<b<<nl;
  else cout<<n-a<<nl;

      
} 
int main()
{

     code();
 
}