#include<bits/stdc++.h>
using namespace std;
#define nn int
#define dd double
#define ll long long int
#define ss string
void code()
{
    nn n;
    cin>>n;
    cout<<2<<" "<<n-1<<"\n";
}
int main()
{
  nn tt;
  cin>>tt;
  while(tt--) code();
}